

function addStudent() {
    var fname = document.getElementById("fname").value;
    var lname = document.getElementById("lname").value;
    var id = document.getElementById("id").value;
    var date=document.getElementById("date").value;
    var gpa=document.getElementById("gpa").value;
    var level=document.getElementById("level").value;
    var status=document.getElementById("status").value;
    var gender=document.getElementById("gender").value;
    var dept=document.getElementById("dept").value;
    var email = document.getElementById("email").value;
    var mobile = document.getElementById("mobile").value;

    //var email_check=/^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    if(level==="1"||level==="2"){
        if(!validatefName(fname)||!validatelName(lname)||!validateId(id)||!validateGPA(gpa)|| !validateGender(gender)||!validateLevel(level)||!validateStatus(status)||!validateEmail(email)||!validateMobile(mobile)){
            return;
        }
    }
    else{
        if(!validatefName(fname)||!validatelName(lname)||!validateId(id)||!validateGPA(gpa)|| !validateGender(gender)||!validateLevel(level)||!validateStatus(status)||!validateDepartment(dept)||!validateEmail(email)||!validateMobile(mobile)){
            return;
        }
    }
    
    

}
function validatefName(fname) {
    var isValid = /^[a-zA-Z\s]*$/.test(fname); 
    if(fname===""){
        document.getElementById("fnameError").innerHTML = "*first Name is required";
    }
    else if (!isValid) {
        document.getElementById("fnameError").innerHTML = "Invalid name";
        return false;
    } else {
        document.getElementById("fnameError").innerHTML = "";
        return true;
    }
}
function validatelName(lname) {
    var isValid = /^[a-zA-Z\s]*$/.test(lname); 
    if(lname===""){
        document.getElementById("lnameError").innerHTML = "*Last Name is required";
    }
    else if (!isValid) {
        document.getElementById("lnameError").innerHTML = "Invalid name";
        return false;
    } else {
        document.getElementById("lnameError").innerHTML = "";
        return true;
    }
}

function validateId(id) {
    var isValid = /^[0-9]{8}$/.test(id);
    if(id===""){
        document.getElementById("idError").innerHTML = "*ID is required"
        return false
    }
    else if (!isValid) {
        document.getElementById("idError").innerHTML = "Invalid ID";
        return false;
    } else {
        document.getElementById("idError").innerHTML = "";
        return true;
    }
}

function validateGPA(gpa) {
     var isValid = /^[0-4]\.\d\d$/.test(gpa)
    if(gpa===""){
        document.getElementById("gpaError").innerHTML = "*GPA is required";
        return false;
    }
    else if (!isValid) {
        document.getElementById("gpaError").innerHTML = "Invalid GPA";
        return false;
    } else {
        document.getElementById("gpaError").innerHTML = "";
        return true;
    }
}

function validateEmail(email) {
    var isValid =/^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/.test(email);

    if(email===""){
        document.getElementById("emailError").innerHTML = "*Email is required";
    }
    else if (!isValid) {
        document.getElementById("emailError").innerHTML = "Invalid email";
    } else {
        document.getElementById("emailError").innerHTML = "";
    }

    return isValid;
}

function validateMobile(mobile) {
     var isValid = /^[0-9]{11}$/.test(mobile);
    if(mobile===""){
        document.getElementById("mobileError").innerHTML = "*Mobile is required";
        return false;
    }
    else if (!isValid) {
        document.getElementById("mobileError").innerHTML = "Invalid mobile number";
        return false;
    } else {
        document.getElementById("mobileError").innerHTML = "";
        return true;
    }
}
function validateStatus(status) {
    if (status==="") {
        document.getElementById("statusError").innerHTML = "*Status is required";
        return false;
    } else {
        document.getElementById("statusError").innerHTML = "";
        return true;
    }

}
function validateGender(gender) {
   if (gender==="") {
        document.getElementById("genderError").innerHTML = "*gender is required";
        return false;
    } else {
        document.getElementById("genderError").innerHTML = "";
        return true;
    }
}
function validateLevel(level) {

    if (level==="") {
        document.getElementById("levelError").innerText = "*level is required";
        return false;
    }
    else {
        document.getElementById("levelError").innerText = "";
        return true;
    }
}
function validateDepartment(dept) {
    if (dept==="") {
        document.getElementById("deptError").innerText = "*Department is required";
        return false;
    } else {
        document.getElementById("deptError").innerText = "";
        return true;
    }
}
function toggleLabel() {
    var selectBox = document.getElementById("level");
    var label = document.getElementById("dept");

    if (selectBox.value ==="1"||selectBox.value==="2") {
      label.disabled = true;
    } else {
      label.disabled = false;
    }
  }