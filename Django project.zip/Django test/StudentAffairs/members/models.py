from django.db import models

class Member(models.Model):
  firstname = models.CharField(max_length=255)
  lastname = models.CharField(max_length=255)
  phone = models.CharField(max_length=11,null=True)
  birth_date = models.DateField(null=True)
  gpa = models.DecimalField(max_digits=4,decimal_places=2,null=True)
  gender = models.CharField(max_length=10,null=True)
  level = models.IntegerField(null=True)
  department = models.CharField(max_length=50,null=True)
  email = models.EmailField(null=True)
  status = models.CharField(max_length=10,null=True)
  
 
