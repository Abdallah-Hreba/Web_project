from django.urls import path
from . import views

urlpatterns = [
    path('',views.home,name='home'),
    path('show/', views.show, name='show'),
    path('add/',views.add,name='add'),
    path('add/addrecord/',views.addrecord,name='addrecord'),
    path('search/',views.search,name='search'),
    path('update/',views.update,name='update'),
    path('update/updaterecord/<int:id>',views.updaterecord,name='updaterecord'),
    path('delete/<int:id>',views.delete,name='delete'),

]
