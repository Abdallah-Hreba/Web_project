from django.shortcuts import render,redirect
from django.http import HttpResponse,HttpResponseRedirect
from django.template import loader
from .models import Member
from django.urls import reverse
from django.contrib import messages
from django.http import JsonResponse
# def index(request):
#     return HttpResponse("Hello now!")

# def index(request):
#    template = loader.get_template('first.html')
#    return HttpResponse(template.render())
########################################################
def show(request):
  mymembers = Member.objects.all().values()
  template = loader.get_template('Showstudents.html')
  context = {
    'mymembers': mymembers,
  }
  return HttpResponse(template.render(context, request))
#############################
def add(request):
  template = loader.get_template('Add.html')
  return HttpResponse(template.render({}, request))

def addrecord(request):
  a=request.POST.get('fname')
  b=request.POST.get('lname')
  c=request.POST.get('ID') 
  d=request.POST.get('mobile')
  e=request.POST.get('birth date')
  f=request.POST.get('gpa')
  g=request.POST.get('Gender')
  h=request.POST.get('Level')
  i=request.POST.get('dept')
  j=request.POST.get('email')
  k=request.POST.get('status')
  if request.method=='POST':
     
    if Member.objects.filter(id=c).exists():

      # message = "*ID already exists\nPlease provide a unique ID."
      alert_script = """
            <script>
                alert("ID already exists Please provide a unique ID");
                window.location.href = "/add";
            </script>
            """
      return HttpResponse(alert_script)
    else:
        member=Member(firstname=a,lastname=b,id=c,phone=d,birth_date=e,gpa=f,gender=g,level=h,department=i,email=j,status=k)
        member.save()
        return HttpResponseRedirect(reverse('show'))
  return render(request, 'Add.html')
##################################################
def home(request):
  template = loader.get_template('HomePage.html')
  return HttpResponse(template.render({}, request))

def search(request):
  template = loader.get_template('searchStudents.html')
  return HttpResponse(template.render({}, request))

def update(request):
  template = loader.get_template('update.html')
  return HttpResponse(template.render({}, request))
##################################################
def updaterecord(request,id):
 student = Member.objects.get(id=id)
 if request.method == 'POST':
        student.phone= request.POST.get('mobile')
        student.gpa= request.POST.get('gpa')
        student.level= request.POST.get('Level')
        student.department= request.POST.get('dept')
        student.email=request.POST.get('email')
        student.status=request.POST.get('status')
        student.save()
        return redirect('show')
 else:
    return render(request, 'update.html', {'student': student})
##########################################################
def delete(request,id):
  member=Member.objects.get(id=id)
  member.delete()
  return HttpResponseRedirect(reverse('show'))
###################################################
def search(request):
    if request.method=='GET':
        search_name = request.GET.get('search_name')
        # print(search_name)
        students = Member.objects.filter(firstname=search_name).values
    else: 
        students = []
    return render(request, 'searchStudents.html', {'students': students ,'search_name': search_name})