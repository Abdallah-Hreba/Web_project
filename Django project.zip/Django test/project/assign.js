
window.onload= function validateForm(){
    var studentId = document.getElementById("student_id").value;
    var studentName = document.getElementById("student_name").value;
    var level = document.getElementById("level").value;
    if (studentId.trim() === "") {
        alert("Please enter a valid Student ID.");
        return false;
    }
    if (!Number.isInteger(Number(studentId))) {
        alert("Student ID must be an integer.");
        return false;
    }
    if (studentName.trim() === "") {
        alert("Please enter a valid Student Name.");
        return false;
    }
    if (!/^[a-zA-Z]+$/.test(studentName)) {
        alert("Student Name must contain only alphabetic characters.");
        return false;
    }
    if (level !== 'level-3') {
        alert('This action is only applicable for students in level 3.');
        return false;
    }
    return true;
    } ;