function showAllStudents() {
    // Retrieve existing students from local storage
    var students = JSON.parse(localStorage.getItem('students')) || [];

    // Display students in the table
    var tableBody = document.querySelector("#studentTable tbody");
    tableBody.innerHTML = '';

    students.forEach(student => {
        var row = `<tr>
                        <td>${student.name}</td>
                        <td>${student.id}</td>
                        <td>${student.date}</td>
                        <td>${student.gpa}</td>  
                        <td>${student.gender}</td>
                        <td>${student.level}</td>
                        <td>${student.dept}</td>
                        <td>${student.email}</td>
                        <td>${student.mobile}</td>
                        <td>${student.status}</td>
                    </tr>`;
        tableBody.innerHTML += row;
    });
}