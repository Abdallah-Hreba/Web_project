function updateStudent() {
    var name = document.getElementById("name").value;
    var id = document.getElementById("id").value;
    var date=document.getElementById("date").value;
    var gpa=document.getElementById("gpa").value;
    var level=document.getElementById("level").value;
    var status=document.getElementById("status").value;
    var gender=document.getElementById("gender").value;
    var dept=document.getElementById("dept").value;
    var email = document.getElementById("email").value;
    var mobile = document.getElementById("mobile").value;
    if(name===''|| name==null)
    {
        alert("name is required");
        return;
    }
    if(id===''|| id==null)
    {
        alert("ID is required");
        return;
    }
    if(email===''|| email==null)
    {
        alert("Email is required");
        return;
    }
    if(dept===''|| dept==null)
    {
        alert("Department is required");
        return;
    }
    if(level===''|| level==null)
    {
        alert("level is required");
        return;
    }
    if(gpa===''|| gpa==null)
    {
        alert("gpa is required");
        return;
    }
    if(gender===''|| gender==null)
    {
        alert("gender is required");
        return;
    }
    if(status===''|| status==null)
    {
        alert("status is required");
        return;
    }
    if(date===''|| date==null)
    {
        alert("date is required");
        return;
    }
    if(mobile===''|| mobile==null)
    {
        alert("mobile is required");
        return;
    }
    
    
var students = JSON.parse(localStorage.getItem('students')) || [];

    // Find the student to update
    var studentToUpdate = students.find(student => student.id === id);

    if (studentToUpdate) {
        studentToUpdate.name=name;
        studentToUpdate.id=id;
        studentToUpdate.email=email;
        studentToUpdate.dept=dept;
        studentToUpdate.date=date;
        studentToUpdate.status=status;
        studentToUpdate.gender = gender;
        studentToUpdate.level = level;
        studentToUpdate.gpa=gpa;
        studentToUpdate.mobile=mobile;

        // Save the updated students array to local storage
        localStorage.setItem('students', JSON.stringify(students));

        alert("Student information updated successfully!");
    } else {
        alert("Student not found!");
    }
}

function deleteStudentById() {
    var idToDelete=document.getElementById("id").value
    var students = JSON.parse(localStorage.getItem('students')) || [];

    // Find the index of the student to delete
    var indexToDelete = students.findIndex(student => student.id === idToDelete);

    if (indexToDelete !== -1) {
        // Remove the student from the array
        students.splice(indexToDelete, 1);

        // Save the updated students array to local storage
        localStorage.setItem('students', JSON.stringify(students));

        alert("Student deleted successfully!");
    } else {
        alert("Student not found!");
    }
}

