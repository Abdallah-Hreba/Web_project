document.addEventListener('DOMContentLoaded', function () {
    const form = document.querySelector('form');
    const resultsTable = document.getElementById('studentsTable');

    form.addEventListener('submit', function (event) {
        event.preventDefault();

        const searchQuery = document.querySelector('input[type="search"]').value.toLowerCase();

        const students = [
            { name: 'Ahmed Khaled', status: 'Active', id: 20210015},
            { name: 'Omar Gamal', status: 'Active', id: 20210270},
            { name: 'Mohamed Ahmed Fathy', status: 'Inactive', id: 20210324},
            { name: 'Aly Ahmed Salah', status: 'Active', id: 20210241},
            { name: 'Abdallah Mahmoud Amin', status: 'Inactive', id: 20211062},
            { name: 'Omar Amer', status: 'Active', id: 20210267},
        ];

        if(searchQuery === ''){
            return;
        }
        
        const searchedStudents = students.filter(student =>
            student.name.toLowerCase().includes(searchQuery) && student.status === 'Active'
        );

        clearTable();

        displayResults(searchedStudents);
    });

    function clearTable() {
        while (resultsTable.tBodies[0].firstChild) {
            resultsTable.tBodies[0].removeChild(resultsTable.tBodies[0].firstChild);
        }
    }

    function displayResults(results) {
        const tbody = resultsTable.tBodies[0];
        results.forEach(student => {
            const row = tbody.insertRow();
            const cell1 = row.insertCell(0);
            const cell2 = row.insertCell(1);
            const cell3 = row.insertCell(2);
            cell1.textContent = student.id;
            cell2.textContent = student.name;
            cell3.textContent = student.status;
        });
    }

});
