function addStudent() {
    var name = document.getElementById("name").value;
    var id = document.getElementById("id").value;
    var date=document.getElementById("date").value;
    var gpa=document.getElementById("gpa").value;
    var level=document.getElementById("level").value;
    var status=document.getElementById("status").value;
    var gender=document.getElementById("gender").value;
    var dept=document.getElementById("dept").value;
    var email = document.getElementById("email").value;
    var mobile = document.getElementById("mobile").value;

    //var email_check=/^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    if(level==="1"||level==="2"){
        if(!validateName(name)||!validateId(id)||!validateGPA(gpa)|| !validateGender(gender)||!validateLevel(level)||!validateStatus(status)||!validateEmail(email)||!validateMobile(mobile)){
            return;
        }
    }
    else{
        if(!validateName(name)||!validateId(id)||!validateGPA(gpa)|| !validateGender(gender)||!validateLevel(level)||!validateStatus(status)||!validateDepartment(dept)||!validateEmail(email)||!validateMobile(mobile)){
            return;
        }
    }
    
    
var student = {
    name: name,
    id: id,
    date:date,
    gpa:gpa,
    level:level,
    status:status,
    gender:gender,
    dept:dept,
    email: email,                                                                    
    mobile: mobile
};

    // Retrieve existing students from local storage
    var students = JSON.parse(localStorage.getItem('students')) || [];

    // Add the new student
    students.push(student);

    // Save the updated students array to local storage
    localStorage.setItem('students', JSON.stringify(students));

    alert("Student added successfully!");
}
function validateName(name) {
    var isValid = /^[a-zA-Z\s]*$/.test(name); 
    if(name===""){
        document.getElementById("nameError").innerHTML = "*Name is required";
    }
    else if (!isValid) {
        document.getElementById("nameError").innerHTML = "Invalid name";
        return false;
    } else {
        document.getElementById("nameError").innerHTML = "";
        return true;
    }
}

function validateId(id) {
    var isValid = /^[0-9]{8}$/.test(id);
    if(id===""){
        document.getElementById("idError").innerHTML = "*ID is required"
        return false
    }
    else if (!isValid) {
        document.getElementById("idError").innerHTML = "Invalid ID";
        return false;
    } else {
        document.getElementById("idError").innerHTML = "";
        return true;
    }
}

function validateGPA(gpa) {
    // var isValid = /^[0-4]\.\d\d$/
    if(gpa===""){
        document.getElementById("gpaError").innerHTML = "*GPA is required";
        return false;
    }
    else if (gpa>"4"||gpa<"0") {
        document.getElementById("gpaError").innerHTML = "Invalid GPA";
        return false;
    } else {
        document.getElementById("gpaError").innerHTML = "";
        return true;
    }
}

function validateEmail(email) {
    var isValid =/^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/.test(email);

    if(email===""){
        document.getElementById("emailError").innerHTML = "*Email is required";
    }
    else if (!isValid) {
        document.getElementById("emailError").innerHTML = "Invalid email";
    } else {
        document.getElementById("emailError").innerHTML = "";
    }

    return isValid;
}

function validateMobile(mobile) {
     var isValid = /^[0-9]{11}$/.test(mobile);
    if(mobile===""){
        document.getElementById("mobileError").innerHTML = "*Mobile is required";
        return false;
    }
    else if (!isValid) {
        document.getElementById("mobileError").innerHTML = "Invalid mobile number";
        return false;
    } else {
        document.getElementById("mobileError").innerHTML = "";
        return true;
    }
}
function validateStatus(status) {
    if (status==="") {
        document.getElementById("statusError").innerHTML = "*Status is required";
        return false;
    } else {
        document.getElementById("statusError").innerHTML = "";
        return true;
    }

}
function validateGender(gender) {
   if (gender==="") {
        document.getElementById("genderError").innerHTML = "*gender is required";
        return false;
    } else {
        document.getElementById("genderError").innerHTML = "";
        return true;
    }
}
function validateLevel(level) {

    if (level==="") {
        document.getElementById("levelError").innerText = "*level is required";
        return false;
    }
    else {
        document.getElementById("levelError").innerText = "";
        return true;
    }
}
function validateDepartment(dept) {
    if (dept==="") {
        document.getElementById("deptError").innerText = "*Department is required";
        return false;
    } else {
        document.getElementById("deptError").innerText = "";
        return true;
    }
}
function toggleLabel() {
    var selectBox = document.getElementById("level");
    var label = document.getElementById("dept");

    if (selectBox.value ==="1"||selectBox.value==="2") {
      label.disabled = true;
    } else {
      label.disabled = false;
    }
  }