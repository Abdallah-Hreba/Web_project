for x in range(4):
    print(x+1)